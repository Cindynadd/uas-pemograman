<?php include "header.php"; ?>
		<div class="container">
		<div class="row">
			<div class="col-md-8">

			<?php 

            if(@$_GET['pesan']=="inputBerhasil"){

            ?>
                    <div class="alert alert-success">
                     Berhasil Dikirim!
                    </div>
            <?php

            }

            ?>
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted">Contact Us</h2>
					<form action="proses-contact.php" method="post">
						<table class="table table-hover">
							<div class="form-group">
							<label for="nama">Nama</label>
								<input type="text" name="nama" class="form-control input-md" placeholder="Isikan nama anda dengan lengkap" required>
							</div>
					
							<div class="form-group">
							<label for="email">Alamat Email</label>
								<input type="email" name="email" class="form-control input-md" placeholder="Isikan alamat email yang masih aktif" required>
							</div>
							
							<div class="form-group">
							<label for="pesan">Pesan</label>
								<textarea name="pesan" class="form-control input-md" required> </textarea>
							</div>
							
								<td>
								<input type="submit" nama="kirim" value="Kirim" class="btn btn-lg btn-info"> <input type="reset" value="Batal" class="btn btn-lg btn-warning">
								</td>
							
						</table>
					</form>
				</div>
      </div>
			</div>
			
	        <div class="col-md-4"> <!-- Awal Kolom Kedua -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <h2 class="text-muted">
                        <span class="glyphicon glyphicon-info-sign"></span> Info Lainnya
                    </h2>
                    <p>Jika Anda membutuhkan bantuan lebih lanjut, jangan ragu untuk menghubungi kami melalui formulir ini.</p>
                </div>
            </div>
        </div> <!-- Akhir Kolom Kedua -->
		</div>
		</div>