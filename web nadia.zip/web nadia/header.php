<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sunset Serenade Cafe</title>

    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="bootstrap/css/style.css" rel="stylesheet">
    <link href="bootstrap/css/responsive.css" rel="stylesheet">
    <link href="styles.css" rel="stylesheet">

    <style>
      body {
        padding-top: 70px; /* Beri jarak agar konten tidak tertimpa navbar */
      }
    </style>
  </head>
  <body>


    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Sunset Serenade Cafe</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
            <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            <li class="nav-item"><a class="nav-link" href="order.php">Reservasi</a></li>

            <!-- Login User -->
            <li class="nav-item"><a class="nav-link" href="login.php">Login Admin</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Awal Konten -->
    <div class="container">
      <!-- Tambahkan konten Anda di sini -->
    </div>
    <!-- Akhir Konten -->

    <!-- Bootstrap JS CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="bootstrap/js/custom.js"></script>
  </body>
</html>


