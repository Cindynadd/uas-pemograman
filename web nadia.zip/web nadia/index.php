<?php include "header.php"; ?>
<!-- Awal script Slider/ Carousel -->
<div id="contoh-carousel" class="carousel slide" data-bs-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-bs-target="#contoh-carousel" data-bs-slide-to="0" class="active"></li>
        <li data-bs-target="#contoh-carousel" data-bs-slide-to="1"></li>
        <li data-bs-target="#contoh-carousel" data-bs-slide-to="2"></li>
    </ol>

    <!-- Carousel items -->
    <div class="carousel-inner">
        <!-- Slider pertama -->
        <div class="carousel-item active">
            <img src="images/sunset cafe.jpg" class="d-block w-100" alt="Berisi keterangan gambar">
            <div class="carousel-caption">
                <h1><b>Sunset Serenade Cafe</b></h1>
                <h4>Cafe di tepi pantai</h4>
                <p>Jalan Melati, Bali, Indonesia<br>(62) 12345 <br>sunsetserenade.cafe@gmail.com</p>
                <a href="about.php" class="btn btn-danger">Baca Lebih Lanjut</a>
            </div>
        </div>
        <!-- Slider kedua -->
        <div class="carousel-item">
            <img src="images/download.jpg" class="d-block w-100" alt="Berisi keterangan gambar">
            <div class="carousel-caption">
                <h1><b>Sunset Serenade Cafe</b></h1>
                <h4>Cafe di tepi pantai</h4>
                <p>Jalan Melati, Bali, Indonesia<br>(62) 12345 <br>sunsetserenade.cafe@gmail.com</p>
                <a href="about.php" class="btn btn-danger">Baca Lebih Lanjut</a>
            </div>
        </div>
        <!-- Slider ketiga -->
        <div class="carousel-item">
            <img src="images/Vacation.jpg" class="d-block w-100" alt="Berisi keterangan gambar">
            <div class="carousel-caption">
                <h1><b>Sunset Serenade Cafe</b></h1>
                <h4>Cafe di tepi pantai</h4>
                <p>Jalan Melati, Bali, Indonesia<br>(62) 12345 <br>sunsetserenade.cafe@gmail.com</p>
                <a href="about.php" class="btn btn-danger">Baca Lebih Lanjut</a>
            </div>
        </div>
    </div>

    <!-- Button Geser Kiri dan Kanan -->
    <a class="carousel-control-prev" href="#contoh-carousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#contoh-carousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
<!-- Akhir script Slider/Carousel -->

<!-- Awal Jumbotron -->
 <center>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h2>Cafe pantai yang tidak biasa</h2>
                <p>Akan ada banyak penampilan band, penyanyi, DJ ternama dan banyak lainnya.</p>
                <p>
                    <a class="btn btn-warning btn-lg" href="menu.php" role="button">Cek Menu</a>
                    <a class="btn btn-danger btn-lg" href="booking.php" role="button">Reservasi</a>
                </p>
            </div>
        </div>
    </div>
</div>
<!-- Akhir Jumbotron -->


<!-- Awal Page -->
<div class="container">
    <!-- Awal Panel -->
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-body">
                <h2 style="text-muted"><span class="glyphicon glyphicon-list"></span>Alamat</h2>
                <p>Jalan Melati, Bali, Indonesia</p>
                <div class="row">
                    <!-- Fasilitas -->
<div class="col-md-12 text-center">
    <h2 class="text-muted"><span class="glyphicon glyphicon-list"></span> Penampilan Band</h2>
    <img src="images/cgrrtsaftsex.jpeg" class="img-thumbnail img-responsive">
    <p>Ada banyak penampilan artis dalam dan luar negeri.<br>
        <a class="btn btn-danger btn-xs" href="about.php" role="button">Selengkapnya</a>
    </p>
</div>

                    <!-- Tambahan fasilitas lainnya -->
                </div>
            </div>
        </div>
    </div>
</div>
</center>
<!-- Akhir Page -->
<?php include "footer.php"; ?>
