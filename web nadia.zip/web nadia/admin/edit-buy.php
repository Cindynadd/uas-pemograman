<?php include "navhead.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-buy.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from pembeli where id_pembeli='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="nama">NAMA</label>
                        <input type="hidden" name="id_pembeli" value="<?php echo $row['id_pembeli']?>" class="form-control">
                        <input type="text" name="nama" value="<?php echo $row['nama']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="no_hp">NO HANDPHONE</label>
                        <input type="number" name="no_hp"  value="<?php echo $row['no_hp']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="email">E-MAIL</label>
                        <input type="text" name="email"  value="<?php echo $row['email']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="waktu">WAKTU</label>
                        <input type="date" name="waktu"  value="<?php echo $row['waktu']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="pembayaran">PEMBAYARAN</label>
                        <select name="pembayaran" class="form-control">
                        <option value="<?php echo $row['pembayaran']?>" selected><?php echo $row['pembayaran']?></option>
                            <option value="cod">COD</option>
                            <option value="transfer">TRANSFER</option>
                        </select>
                    </div>
                    <br>
                    <br>


                    <input type="submit" name="kirim" value="Ubah" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger"> 
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>