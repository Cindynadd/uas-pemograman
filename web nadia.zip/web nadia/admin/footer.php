<div class="container">
        <div class="copyright">
          <center>
                <p style="color:#1E90FF">Sunset Serenade Cafe</p>
                <p style="color:#1E90FF">© Copyright 2025 <b>Cindy Nadia</b>. All Rights Reserved</p>
          </center>
        </div>
        </div>
    </div>
      <script src="bootstrap/js/jquery.min.js"></script>
	    <script src="bootstrap/js/bootstrap.min.js"></script>
	    <script src="bootstrap/js/dataTables.bootstrap.min.js"></script>
	   <script src="bootstrap/js/jquery.dataTables.js"></script>
	    <script src="bootstrap/js/scripts.js"></script>
  </body>
</html>