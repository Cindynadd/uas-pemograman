<?php

include "../koneksi.php";

$id=$_POST['id_pembeli'];
$nama=$_POST['nama'];
$no_hp=$_POST['no_hp'];
$waktu=$_POST['waktu'];
$pembayaran=$_POST['pembayaran'];


$ubah=$koneksi->query("update pembeli set nama='$nama', no_hp='$no_hp', email='$email', waktu='$waktu', pembayaran='$pembayaran'  where id_pembeli='$id'");


if($ubah==true){

    header("location:tampil-buy.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>