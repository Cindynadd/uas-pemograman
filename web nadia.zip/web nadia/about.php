  <?php include "header.php";?>
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-8"><!-- Awal Kolom Pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> ABOUT US</h2>
						<img src="images/gambar cafe1.jpg" alt="" width="450" height="250" class="img-thumbnail img-responsive">
						<p>Suatu cafe yang didirikan oleh seorang perempuan bernama Cindy Nadia Salsabila. Sebuah tempat yang menawarkan pengalaman romantis dan tidak terlupakan dengan pemandangan matahari terbenam yang sangat indah di tepi pantai. Tentunya, buat kalian yang gemar dengan fotografi dan videografi, pastinya cafe kami adalah tempat yang wajib kalian kunjungi, dan juga ini adalah tempat ideal untuk bersantai serta menghabiskan waktu bersama pasangan, keluarga dan teman. Rayakan waktu terbaikmu bersama kami. <br/><br/>
							<ul>
						<p class="text-center"><B> Jam Buka </B>
						<li>Sesi pagi/Sesi 1 (06.00 - 12.00)</li>
						<li>Sesi sore/Sesi 2 (15.00 - 03.00)</li>
						</ul>
				
						Nikmati berbagai pilihan kopi dan makanan ringan berkualitas sambil merasakan angin laut  yang sejuk ditemani dengan Live Music dan terkadang kami mengundang tamu spesial yang tentunya sangat menarik. Datanglah dan rasakan sendiri keajaiban senja di Sunset Serenade Cafe.   
				</p>
				</div> 
      </div>
			</div><!-- Akhir Kolom Pertama -->

				<div class="col-md-4">
  <!-- Awal kolom kedua -->
  <div class="panel panel-default">
    <div class="panel-body">
      <h2 class="text-muted">
        <span class="text-center glyphicon glyphicon-tasks"></span> Info Lainnya
      </h2>
      <h4>Menu Baru</h4> <!-- Menambahkan text-center hanya pada bagian ini -->
      <img src="images/Wholesome Breakfast Recipes.jpg" alt="" width="270" height="200" class="img-thumbnail img-responsive mx-auto"> <!-- Menambahkan mx-auto untuk memusatkan gambar -->
      <p>Cafe kami berlokasi <b>di Bali</b> rasakan menu baru kami. Untuk melihat menu silakan klik link dibawah <br/>
      	<p class="text-center">
        <a class="btn btn-danger btn-xs" href="menu.php" role="button">Menu</a>
      </p>
    </div>
  </div>
</div>

			</div><!-- Akhir Kolom Kedua -->
		</div><!-- Akhir Baris -->
		</div><!--  Akhir Page -->
		
<?php include "footer.php"; ?>    

