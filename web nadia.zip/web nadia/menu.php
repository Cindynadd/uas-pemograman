<?php include "header.php"; ?>

<!-- Awal Page -->
<div class="container">
  <h2 class="text-muted text-center my-4"><span class="glyphicon glyphicon-cutlery"></span> Menu</h2>
  
  <!-- Pizza Section --> 
  <div class="menu-section">
    <h3 class="text-muted">Main Course (Makanan Utama)</h3>
    <div class="row">
      <div class="col-md-4">
  <div class="card">
    <img src="images/Kimchi Burger Sliders.jpg" alt="Kimchi Burger Sliders" class="menu-img">
    <div class="card-body text-center">
      <h5>Kimchi Burger Sliders</h5>
      <p>Burger dengan kimchi dan daging yang super tebal</p>
      <p class="price">Rp 35.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Kimchi Burger Sliders" data-price="35.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="card">
    <img src="images/Grilled Chipotle Burger.jpg" alt="Grilled Chipotle Burger" class="menu-img">
    <div class="card-body text-center">
      <h5>Grilled Chipotle Burger</h5>
      <p>Burger yang dilengkapi dengan alpukat, keju melted, lada, dan saus chipotle spesial</p>
      <p class="price">Rp 70.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Grilled Chipotle Burger" data-price="70.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
        <div class="card">
          <img src="images/Truffle Burgers.jpg" alt="Truffle Burger" class="menu-img">
            <div class="card-body text-center">
            <h5>Truffle Burger</h5>
            <p>Burger dengan kentang, salad hijau dan parmesan </p>
            <p class="price">Rp 50.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Truffle Burger" data-price="50.000">Add to Cart</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
  <div class="col-md-4">
  <div class="card">
    <img src="images/pizza1.jpg" alt="pizza" class="menu-img">
    <div class="card-body text-center">
      <h5>Pepperoni Tomatos Pizza</h5>
      <p>Pizza dengan topping tomat cherry segar</p>
      <p class="price">Rp 70.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Pepperoni Tomatos Pizza" data-price="70.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="card">
    <img src="images/Pepperoni and Burrata Pizza with Pesto.jpg" alt="Pepperoni and Burrata Pizza with Pesto" class="menu-img">
    <div class="card-body text-center">
      <h5>Pepperoni and Burrata Pizza with Pesto</h5>
      <p>Pizza dengan topping Pepperoni, tomat cherry dan daun mint.</p>
      <p class="price">Rp 70.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Pepperoni and Burrata Pizza with Pesto" data-price="70.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="card">
    <img src="images/Oval Pizza Boats.jpg" alt="Oval Pizza Boats" class="menu-img">
    <div class="card-body text-center">
      <h5>Oval Pizza Boats</h5>
      <p>Pizza berbentuk oval dengan topping potongan daging</p>
      <p class="price">Rp 70.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Oval Pizza Boats" data-price="70.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="row">
	<div class="col-md-4">
  <div class="card">
    <img src="images/Skillet Deep Dish Pizza.jpg" alt="Skillet Deep Dish Pizza" class="menu-img">
    <div class="card-body text-center">
      <h5>Skillet Deep Dish Pizza</h5>
      <p>Pizza berlapis tebal dengan kerak renyah di bagian luar dan lembut di dalam, isian saus tomat, keju meleleh, dan aneka topping lezat.</p>
      <p class="price">Rp 100.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Skillet Deep Dish Pizza" data-price="100.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="card">
    <img src="images/Cornbread with Jalapeno.jpg" alt="Cornbread with Jalapeno" class="menu-img">
    <div class="card-body text-center">
      <h5>Cornbread with Jalapeno</h5>
      <p>Pizza dengan isian jagung yang dipanggang renyah</p>
      <p class="price">Rp 80.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Cornbread with Jalapeno" data-price="80.000">Add to Cart</button>
    </div>
  </div>
</div>
<div class="col-md-4">
  <div class="card">
    <img src="images/Pepperoni Pizza.jpg" alt="Pepperoni Pizza" class="menu-img">
    <div class="card-body text-center">
      <h5>Pepperoni Pizza</h5>
      <p>Pizza dengan topping daging panggang</p>
      <p class="price">Rp 70.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Pepperoni Pizza" data-price="70.000">Add to Cart</button>
    </div>
  </div>
</div>

  <!-- Dessert Section -->
  <div class="menu-section mt-5">
    <h3 class="text-muted">Dessert</h3>
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <img src="images/Blueberry Sauce.jpg" alt="Blueberry Sauce" class="menu-img">
          <div class="card-body text-center">
            <h5>Cheesecake Blueberry Sauce</h5>
            <p>Kue keju lembut dengan topping blueberry dan bobba perpaduan rasa manis dan asin.</p>
            <p class="price">Rp 35.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Cheesecake Blueberry Sauce" data-price="35.000">Add to Cart</button>
          </div>
        </div>
      </div>
      <div class="col-md-4">
  <div class="card">
    <img src="images/Mini Pumpkin Pies.jpg" alt="Mini Pumpkin Pies" class="menu-img">
    <div class="card-body text-center">
      <h5>Mini Pumpkin Pies</h5>
      <p>Pie berjumlah 5 berukuran sedang dengan rasa yang manis.</p>
      <p class="price">Rp 60.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Mini Pumpkin Pies" data-price="60.000">Add to Cart</button>
    </div>
  </div>
</div>
  <div class="col-md-4">
  <div class="card">
    <img src="images/M&M’s and Chocolate Chip Monster Cookies.jpg" alt="M&M’s and Chocolate Chip Monster Cookies" class="menu-img">
    <div class="card-body text-center">
     	 <h5>M&M’s and Chocolate Chip Monster Cookies</h5>
      	<p>Cookies lembut dengan topping chocolate chip berwarna warni</p>
        <p class="price">Rp 35.000</p>
        <button class="btn btn-primary add-to-cart" data-name="M&M’s and Chocolate Chip Monster Cookies" data-price="35.000">Add to Cart</button>
    	</div>
  	</div>
	</div>
</div>
</div>
   
<!-- Soup Section -->
    <div class="menu-section">
        <h3 class="text-muted">Soup</h3>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img src="images/Butternut Squash Soup.jpg" alt="Butternut Squash Soup" class="menu-img">
                    <div class="card-body text-center">
                        <h5>Butternut Squash Soup</h5>
                        <p> sup lembut dibuat dari labu butternut yang dipanggang hingga karamel, lalu dihaluskan dengan kaldu, rempah-rempah. Sempurna dinikmati saat hangat dengan taburan biji labu panggang atau roti kering</p>
                        <p class="price">Rp 60.000</p>
                        <button class="btn btn-primary add-to-cart" data-name="Butternut Squash Soup" data-price="60.000">Add to Cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images/Cream of Mushroom Soup.jpg" alt="Cream of Mushroom Soup" class="menu-img">
                    <div class="card-body text-center">
                        <h5>Cream of Mushroom Soup</h5>
                        <p>dibuat dari jamur segar yang ditumis dengan bawang merah dan bawang putih, dimasak dengan kaldu dan krim untuk menghasilkan tekstur yang halus dan rasa yang gurih</p>
                        <p class="price">Rp 60.000</p>
                        <button class="btn btn-primary add-to-cart" data-name="Cream of Mushroom Soup" data-price="60.000">Add to Cart</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images/Baked Tofu with Mushrooms.jpg" alt="Baked Tofu with Mushrooms" class="menu-img">
                    <div class="card-body text-center">
                        <h5>Baked Tofu with Mushrooms</h5>
                        <p>Potongan tahu yang dipanggang hingga keemasan, dipadukan dengan jamur yang dimasak dengan bumbu gurih seperti bawang putih, kecap, dan rempah-rempah. Teksturnya renyah di luar dan lembut di dalam</p>
                        <p class="price">Rp 65.000</p>
                        <button class="btn btn-primary add-to-cart" data-name="Baked Tofu with Mushrooms" data-price="65.000">Add to Cart</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


  <!-- Breakfast Section -->
  <div class="menu-section mt-5">
    <h3 class="text-muted">Breakfast (06:00 - 11:00)</h3>
    <div class="row">
      <div class="col-md-4">
        <div class="card">
         <img src="images/Wholesome Breakfast Recipes.jpg" alt="Wholesome Breakfast Recipes" class="menu-img">
          <div class="card-body text-center">
            <h5>Toasted Oat & Egg Delight</h5>
            <p>Kombinasi oat creamy, roti panggang, dan telur mata sapi, dihiasi tomat cherry</p>
            <p class="price">Rp 35.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Toasted Oat & Egg Delight" data-price="35.000">Add to Cart</button>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="images/These Fluffy Pancakes.jpg" alt="These Fluffy Pancakes" class="menu-img">
          <div class="card-body text-center">
            <h5>These Fluffy Pancakes</h5>
            <p>Pancake lembut dengan sirup maple, mentega leleh, dan taburan buah segar. Perpaduan rasa manis yang sempurna dengan tekstur ringan dan fluffy yang meleleh di mulut</p>
            <p class="price">Rp 35.000</p>
            <button class="btn btn-primary add-to-cart" data-name="These Fluffy Pancakes" data-price="35.000">Add to Cart</button>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="images/Smoky Bacon Cheddar Breakfast Hash.jpg" alt="Smoky Bacon Cheddar Breakfast Hash" class="menu-img">          
          <div class="card-body text-center">
            <h5>Smoky Bacon Cheddar Breakfast Hash</h5>
            <p>Kentang renyah, daging asap beraroma smoky, dan keju cheddar leleh yang menyatu sempurna. Disajikan dengan telur setengah matang di atasnya </p>
            <p class="price">Rp 50.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Smoky Bacon Cheddar Breakfast Hash" data-price="50.000">Add to Cart</button>
          </div>
        </div>
      </div>
       <div class="row">
      <div class="col-md-4">
        <div class="card">
         <img src="images/Cowboy Skillet BREAKFAST AND BRUNCH.jpg" alt="Cowboy Skillet BREAKFAST AND BRUNCH" class="menu-img">
          <div class="card-body text-center">
            <h5>Cowboy Skillet BREAKFAST AND BRUNCH</h5>
            <p>Kentang renyah, sosis dan daging asap yang gurih, paprika segar, dan keju leleh. Disajikan langsung dari wajan panas dengan telur mata sapi </p>
            <p class="price">Rp 55.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Cowboy Skillet BREAKFAST AND BRUNCH" data-price="55.000">Add to Cart</button>
          </div>
        </div>
      </div>
    <div class="col-md-4">
        <div class="card">
          <img src="images/avocado scrambled egg toast.jpg" alt="avocado scrambled egg toast" class="menu-img">          
          <div class="card-body text-center">
            <h5>Avocado scrambled egg toast</h5>
            <p>Roti panggang dengan telur dadar/omelet dan topping potongan alpukat diatasnya</p>
            <p class="price">Rp 50.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Avocado scrambled egg toast" data-price="50.000">Add to Cart</button>
          </div>
        </div>
      </div>
       <div class="col-md-4">
        <div class="card">
          <img src="images/Chili Oil Fried Egg.jpg" alt="Chili Oil Fried Egg" class="menu-img">          
          <div class="card-body text-center">
            <h5>Chili Oil Fried Egg</h5>
            <p>Roti panggang dengan telur mata sapi yang disiram minyak cabai</p>
            <p class="price">Rp 35.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Chili Oil Fried Egg" data-price="35.000">Add to Cart</button>
          </div>
        </div>
      </div>
  </div>
 </div>

   <!-- Alcoholic Beverages Section --> 
  <div class="menu-section">
    <h3 class="text-muted">Alcoholic Beverages(Minuman Beralkohol)</h3>
    <div class="row">
   <div class="col-md-4">
  <div class="card">
    <img src="images/Army and Navy.jpg" alt="Army and Navy" class="menu2-img">
    <div class="card-body text-center">
      <h5>Army and Navy</h5>
      <p>Koktail klasik dengan campuran gin, jus lemon segar, dan sirup orgeat yang memberikan sentuhan rasa kacang almond. Dengan keseimbangan rasa asam dan manis</p>
      <p class="price">Rp 90.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Army and Navy" data-price="90.000">Add to Cart</button>
    </div>
  </div>
</div> 
<div class="col-md-4">
  <div class="card">
    <img src="images/Cinnamon Maple Whiskey Sour.jpg" alt="Cinnamon Maple Whiskey Sour" class="menu2-img">
    <div class="card-body text-center">
      <h5>Cinnamon Maple Whiskey Sour</h5>
      <p>Whiskey yang kaya rasa, sirup maple yang manis dan perasan lemon, dengan sentuhan kayu manis yang hangat. Minuman ini memberikan keseimbangan rasa manis, asam, dan hangat</p>
      <p class="price">Rp 90.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Cinnamon Maple Whiskey Sour" data-price="90.000">Add to Cart</button>
    </div>
  </div>
</div> 
<div class="col-md-4">
        <div class="card">
          <img src="images/Elixir of Love.jpg" alt="Elixir of Love" class="menu2-img">
            <div class="card-body text-center">
            <h5>Elixir of Love</h5>
            <p>Perpaduan kelembutan buah berri segar, sentuhan lemon yang menyegarkan, dan manisnya madu, disempurnakan dengan sirup mawar dan sedikit soda</p>
            <p class="price">Rp 90.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Elixir of Love" data-price="90.000">Add to Cart</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
  <div class="col-md-4">
  <div class="card">
    <img src="images/Pantai cilacap.jpg" alt="Coffe" class="menu2-img">
    <div class="card-body text-center">
      <h5>Coffe</h5>
      <p>Coffe susu</p>
      <p class="price">Rp 50.000</p>
      <button class="btn btn-primary add-to-cart" data-name="Coffe" data-price="50.000">Add to Cart</button>
    </div>
  </div>
</div>

<div class="col-md-4">
        <div class="card">
          <img src="images/download (3).jpg" alt="Le Mortelle" class="menu2-img">
            <div class="card-body text-center">
            <h5>Le Mortelle</h5>
            <p>Minuman anggur warna hitam pekat dan aroma kompleks. Diproduksi dari kebun anggur terbaik di Italia, menawarkan rasa yang kaya dengan sentuhan buah gelap, rempah, dan sedikit tanin yang lembut.</p>
            <p class="price">Rp 200.000</p>
            <button class="btn btn-primary add-to-cart" data-name="Le Mortelle" data-price="200.000">Add to Cart</button>
          </div>
        </div>
      </div>

     <!-- Keranjang Belanja -->
  <div class="cart-section mt-5">
    <h3 class="text-muted">Keranjang Belanja</h3>
    <ul id="cart-items" class="list-group"></ul>
    <p class="mt-3 text-center"><strong>Total: Rp <span id="cart-total">0</span></strong></p>
    <button class="btn btn-success" id="checkout">Checkout</button>
  </div>
</div>

<!-- Popup Konfirmasi Checkout -->
<div id="checkout-modal" class="modal" style="display:none;">
  <div class="modal-content text-center">
    <h4>Konfirmasi Pesanan</h4>
    <ul id="checkout-items" class="list-group"></ul>
    <p class="mt-3"><strong>Total: Rp <span id="checkout-total">0</span></strong></p>
    <button class="btn btn-danger" id="close-modal">Batal</button>
    <a href="order.php" class="btn btn-success">Proses Pembayaran</a>
  </div>
</div>

<script>
  let cart = [];

  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
      let name = this.getAttribute('data-name');
      let price = parseInt(this.getAttribute('data-price'));
      cart.push({ name, price });
      updateCart();
    });
  });

  function updateCart() {
    let cartItems = document.getElementById('cart-items');
    let cartTotal = document.getElementById('cart-total');
    let checkoutItems = document.getElementById('checkout-items');
    let checkoutTotal = document.getElementById('checkout-total');
    
    cartItems.innerHTML = '';
    checkoutItems.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
      total += item.price;
      let li = document.createElement('li');
      li.classList.add('list-group-item');
      li.textContent = `${item.name} - Rp ${item.price}`;
      cartItems.appendChild(li);
      
      let liCheckout = li.cloneNode(true);
      checkoutItems.appendChild(liCheckout);
    });
    cartTotal.textContent = total;
    checkoutTotal.textContent = total;
  }

  document.getElementById('checkout').addEventListener('click', function() {
    document.getElementById('checkout-modal').style.display = 'flex';
  });

  document.getElementById('close-modal').addEventListener('click', function() {
    document.getElementById('checkout-modal').style.display = 'none';
  });
  
  document.getElementById('checkout').addEventListener('click', function() {
    // Simpan pesanan ke localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Arahkan ke halaman order.php
    window.location.href = "order.php";
});

</script>

<?php include "footer.php"; ?>