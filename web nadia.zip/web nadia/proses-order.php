<?php

$nama=$_POST['nama'];
$no_hp=$_POST['no_hp'];
$email=$_POST['email'];
$waktu=$_POST['waktu'];
$pembayaran=$_POST['pembayaran'];



include "koneksi.php";

$simpan=$koneksi->query("insert into pembeli(nama,no_hp,email,waktu,pembayaran) 
                        values ('$nama','$no_hp','$email','$waktu','$pembayaran')");

if($simpan==true){

    header("location:order.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>