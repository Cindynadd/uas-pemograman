  <!-- FOOTER -->
<div class="container-fluid">
  <div class="row">
    <!-- Heading Events di Tengah -->
    <div class="col-12">
      <h3 style="text-align: center; margin-bottom: 20px;">
        <span class="glyphicon glyphicon-bullhorn"></span> Events
      </h3>
    </div>

    <!-- Kontainer untuk Kolom Events -->
    <div class="col-md-6">
      <!-- Kolom 1 -->
      <ul class="list-group">
        <li class="list-group-item"><a href="#">Rayakan akhir tahun kamu bersama kami</a></li>
        <li class="list-group-item"><a href="#">Nikmati penampilan Rose Blackpink di akhir tahun</a></li>
        <li class="list-group-item"><a href="#">Pesta Kembang api</a></li>
        <li class="list-group-item"><a href="#">Khusus akhir tahun buka 24 jam</a></li>
      </ul>
    </div>

    <div class="col-md-6">
      <!-- Kolom 2 -->
      <ul class="list-group">
        <li class="list-group-item"><a href="#">Rasakan menu sarapan baru</a></li>
        <li class="list-group-item"><a href="#">Nikmati penampilan band favoritmu di Maret</a></li>
        <li class="list-group-item"><a href="#">Rayakan hari Valentine dengan dinner romantis</a></li>
        <li class="list-group-item"><a href="#">..</a></li>
      </ul>
    </div>
  </div>

  <!-- Footer Bawah -->
  <div class="row mt-4">
    <div class="col-12 text-center">
      <p>
        Copyright &copy; 2024 Website Sunset Serenade Cafe
        <br />
      </p>
      <p>
        <span class="btn btn-danger btn-xs">PERHATIAN!!</span> Semua informasi di halaman ini memiliki hak cipta, Anda tidak diperkenankan untuk menyebarluaskan tanpa seizin pengelola website.
      </p>
    </div>
  </div>
</div>
<!-- Akhir FOOTER -->

<!-- JavaScript -->
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/dataTables.bootstrap.min.js"></script>
<script src="bootstrap/js/jquery.dataTables.js"></script>
<script src="bootstrap/js/scripts.js"></script>
</body>
</html>
