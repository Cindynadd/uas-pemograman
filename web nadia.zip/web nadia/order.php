<?php include "header.php"; ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(@$_GET['pesan'] == "inputBerhasil"){ ?>
                <div class="alert alert-success">
                    Pesanan Berhasil!<br>
                    Rincian Pembelian Dikirim Melalui E-mail!
                </div>
            <?php } ?>
            
            <h2 class="text-muted text-center my-4">Formulir Pemesanan</h2>
            <form action="proses-order.php" method="POST" onsubmit="clearCart()">
                <div class="form-group">
                    <label for="nama">NAMA</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="no_hp">NO HANDPHONE</label>
                    <input type="number" name="no_hp" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="waktu">TANGGAL</label>
                    <input type="date" name="waktu" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="email">E-MAIL</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="pembayaran">PEMBAYARAN</label>
                    <select name="pembayaran" class="form-control" required onchange="toggleBankOptions()">
                        <option value="">-- PILIH PEMBAYARAN --</option>
                        <option value="cod">COD</option>
                        <option value="transfer">TRANSFER</option>
                    </select>
                </div>

                <div class="form-group" id="bank-options" style="display: none;">
                    <label for="bank">PILIH BANK / E-WALLET</label>
                    <select name="bank" class="form-control">
                        <option value="">-- PILIH BANK / E-WALLET --</option>
                        <option value="bca">BCA</option>
                        <option value="bni">BNI</option>
                        <option value="bri">BRI</option>
                        <option value="mandiri">Mandiri</option>
                        <option value="dana">DANA</option>
                        <option value="shopeepay">ShopeePay</option>
                    </select>
                </div>

                <h3 class="text-muted">Rincian Pesanan</h3>
                <ul id="order-items" class="list-group"></ul>
                <p class="mt-3 text-center"><strong>Total: Rp <span id="order-total">0</span></strong></p>
                
                <input type="submit" name="kirim" value="Kirim" class="btn btn-info">
                <a class="btn btn-info" href="menu.php" role="button">Kembali</a>
            </form>
        </div>
    </div>
</div>

    
<script>
     document.addEventListener('DOMContentLoaded', function () {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let orderItems = document.getElementById('order-items');
        let orderTotal = document.getElementById('order-total');
        let total = 0;
        
        orderItems.innerHTML = '';
        cart.forEach(item => {
            total += item.price;
            let li = document.createElement('li');
            li.classList.add('list-group-item');
            li.textContent = `${item.name} - Rp ${item.price}`;
            orderItems.appendChild(li);
        });
        orderTotal.textContent = total;
    });
    
    function clearCart() {
        localStorage.removeItem('cart');
    }

    function toggleBankOptions() {
        let pembayaran = document.querySelector('select[name="pembayaran"]').value;
        let bankOptions = document.getElementById('bank-options');
        bankOptions.style.display = pembayaran === "transfer" ? "block" : "none";
    }
    
    document.addEventListener('DOMContentLoaded', function () {
        const itemPrices = {
            cctv_traffic: 300000,
            cctv_bullet: 200000,
            cctv_rotate: 250000,
            cctv_webcam: 150000,
            cctv_ai: 150000,
            cctv_portabel: 150000,
        };

        const shippingCosts = {
            MEDAN_AMPLAS: 15000,
            MEDAN_AREA: 15000,
            MEDAN_BARAT: 15000,
            MEDAN_BARU: 15000,
            MEDAN_BELAWAN: 20000,
            MEDAN_DELI : 15000,
            MEDAN_DENAI: 15000,
            MEDAN_HELVETIA: 15000,
            MEDAN_JOHOR: 15000,
            MEDAN_KOTA : 10000,
            MEDAN_LABUHAN : 20000,
            MEDAN_MAIMUN: 15000,
            MEDAN_MARELAN: 20000,
            MEDAN_PERJUANGAN: 20000,
            MEDAN_PETISAH: 15000,
            MEDAN_POLONIA: 15000,
            MEDAN_SUNGGAL: 10000,
            MEDAN_SELAYANG: 10000,
            MEDAN_TEMBUNG: 10000,
            MEDAN_TUNTUNGAN: 20000,
            MEDAN_TIMUR: 15000,
        };

        function updateOngkir() {
            const selectedDistrict = document.querySelector('select[name="kecamatan"]').value;
            const selectedItem = document.querySelector('select[name="barang"]').value;
            const jumlahBarang = parseInt(document.querySelector('input[name="jumlah_barang"]').value) || 0;

            const ongkir = shippingCosts[selectedDistrict] || 0;
            const hargaBarang = itemPrices[selectedItem] || 0;

            const totalHarga = (hargaBarang * jumlahBarang) + ongkir;

            document.getElementById('ongkir').value = `Rp.${ongkir}`;
            document.getElementById('total').value = `Rp.${totalHarga}`;
        }

        document.querySelector('select[name="kecamatan"]').addEventListener('change', updateOngkir);
        document.querySelector('select[name="barang"]').addEventListener('change', updateOngkir);
        document.querySelector('input[name="jumlah_barang"]').addEventListener('input', updateOngkir);
    });
</script>

    <br>
    <br>

<?php include "footer.php";?>