<?php

$koneksi= new mysqli("localhost","root","","nadia.sql");
//$koneksi= new mysqli("HOST_ATAU_IP_SERVE","USERNAME_AKSES_MYSQL","PASSWORD_MYSQL","NAMA_DATABASE");

?>